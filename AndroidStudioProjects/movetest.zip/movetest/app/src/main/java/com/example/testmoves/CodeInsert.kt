package com.example.testmoves

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CodeInsert : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code_insert)
    }
}
